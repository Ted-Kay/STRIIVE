# STRIIVETECH Multi-Page Website - Clean Executive Design

## Overview
A complete multi-page website redesign for STRIIVETECH featuring a **clean, minimal, executive aesthetic** inspired by Tesla, Apple, and Sika websites. The design emphasizes bright, professional layouts with exceptional typography and generous white space.

## Design Philosophy
- **Clean & Minimal:** Apple-inspired simplicity
- **Executive & Professional:** Corporate credibility
- **Bright & Airy:** Maximum white space
- **Digital Publication:** Magazine-quality layouts

## Color Scheme
- **Primary Red:** #E31E24 (vibrant, energetic)
- **Dark Red:** #B91C22 (hover states, gradients)
- **White:** #FFFFFF (primary background)
- **Light Gray:** #F5F5F7 (subtle backgrounds - Apple style)
- **Text Dark:** #1D1D1F (primary text)
- **Text Gray:** #6E6E73 (secondary text)

## Typography
**Primary Font:** Inter
- Clean, modern sans-serif
- Excellent readability at all sizes
- Used by Figma, GitHub, Mozilla
- Similar to SF Pro (Apple) and Gotham (Tesla)
- Weight range: 300-800

### Font Usage
- **Headers:** Inter 700-800 (Bold/Extra Bold)
- **Body Text:** Inter 400-500 (Regular/Medium)
- **Labels:** Inter 600 (Semi Bold, uppercase, letterspaced)
- **Letter Spacing:** -0.02em to -0.03em for large headings
- **Antialiasing:** -webkit-font-smoothing for crisp rendering

## Page Structure

### 1. **index.html** - Home & Engage
**Features:**
- Frosted glass navigation (Apple-style backdrop blur)
- Clean hero with centered content
- Minimal stat cards
- Simple, elegant contact form
- Light gray card backgrounds
- Pill-shaped buttons (980px border-radius)

### 2. **capabilities.html** - Capabilities
**Features:**
- Light gray hero section
- Grid of capability cards with hover lifts
- Minimal bullet points with red dots
- Clean typography hierarchy
- Red CTA section at bottom

### 3. **projects.html** - Projects Portfolio
**Features:**
- Sticky filter bar
- Pill-shaped filter buttons
- Project cards with red headers
- Clean list formatting
- Minimal, bright interface

### 4. **leadership.html** - Leadership Team
**Features:**
- Clean team grid
- Featured CEO card with red background
- Light gray card backgrounds
- Professional photo placeholders
- Simple value cards

### 5. **process.html** - Methodology & Process
**Features:**
- Minimal timeline design
- Circular red markers
- Light gray content cards
- Clean detail boxes
- Red CTA section

## Design Elements

### Navigation
- Fixed, translucent header
- Backdrop blur effect
- Minimal design
- Smooth opacity transitions
- No underlines, just opacity changes

### Buttons
- Pill-shaped (border-radius: 980px)
- Two styles: Primary (red) and Secondary (outline)
- Subtle hover effects (scale, not translation)
- Clean, modern appearance

### Cards
- Light gray backgrounds (#F5F5F7)
- 12px border radius
- Subtle hover lifts (4px translateY)
- No heavy shadows
- Clean, minimal borders

### Spacing
- Generous padding and margins
- Consistent vertical rhythm
- Breathing room between elements
- Maximum readability

### Colors
- Predominantly white backgrounds
- Red used sparingly for accents
- Light gray for subtle depth
- Clean, professional palette

## Layout Principles

### White Space
- Abundant negative space
- Content breathes
- Not cluttered or cramped
- Professional, executive feel

### Typography Hierarchy
- Clear size differences
- Consistent weight usage
- Proper line-height (1.6 for body)
- Tight leading for headlines (1.05-1.1)

### Grid Systems
- Clean, aligned grids
- Responsive breakpoints
- Consistent gaps
- Modern CSS Grid

## Responsive Design
All pages adapt seamlessly:
- **Desktop:** Full experience
- **Tablet:** Adjusted grids
- **Mobile:** Stacked layouts, hidden nav

## Technical Features
- Pure CSS (no frameworks)
- Minimal JavaScript (only for interactions)
- Backdrop filter effects
- Smooth transitions
- Optimized font loading
- Semantic HTML5

## Inspiration Sources

### Tesla (tesla.com)
- Minimal design
- Large typography
- Generous white space
- Pill-shaped buttons

### Apple (apple.com)
- Frosted glass navigation
- SF Pro-like typography (using Inter)
- Light gray backgrounds
- Clean hierarchy

### Sika (gha.sika.com)
- Professional corporate feel
- Clean layouts
- Bright, trustworthy design
- Executive aesthetic

## Key Improvements Over Previous Version
1. **Cleaner Typography:** Inter font throughout
2. **More White Space:** Breathing room everywhere
3. **Minimal Design:** Removed unnecessary elements
4. **Professional Polish:** Executive-grade quality
5. **Bright Interface:** Light, airy feel
6. **Better Hierarchy:** Clear visual organization
7. **Simplified Interactions:** Subtle, professional animations

## File Organization
```
index.html          → Home & Engage
capabilities.html   → Core Capabilities
projects.html       → Projects Portfolio
leadership.html     → Leadership Team
process.html        → Methodology & Process
README.md          → This file
```

## Best Practices Applied
- **Apple's Design Language:** Minimalism, quality, polish
- **Tesla's Bold Typography:** Large, confident headlines
- **Sika's Professional Tone:** Corporate credibility
- **Modern Web Standards:** Clean code, semantic HTML
- **Performance:** Optimized loading, minimal dependencies

## Brand Identity
The design maintains STRIIVETECH's brand while adopting a more **clean, executive, and professional** aesthetic suitable for corporate clients and high-value projects.

**Color Usage:**
- Red: Accents, CTAs, markers, highlights
- White: Primary background, clean canvas
- Light Gray: Subtle depth, card backgrounds
- Text: Dark for hierarchy, gray for secondary

This design positions STRIIVETECH as a **premium, professional, intelligence-led** consultancy with exceptional attention to detail and executive-grade quality.
